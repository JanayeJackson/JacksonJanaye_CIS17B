<?php
include("./includes/header.php");
include("./includes/gameboard.html");
include("./includes/footer.html");
?>
