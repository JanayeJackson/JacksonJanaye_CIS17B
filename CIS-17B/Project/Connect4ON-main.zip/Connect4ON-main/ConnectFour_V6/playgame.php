<?php
session_start();
?>

<?php
include("./includes/header.php");
?>

<?php
include("./includes/gameboard.html");
?>

<?php
include("./includes/footer.html");
?>

