<?php
include("./includes/gameboard.html");
?>

<?php
include("./includes/footer.html");
?>

