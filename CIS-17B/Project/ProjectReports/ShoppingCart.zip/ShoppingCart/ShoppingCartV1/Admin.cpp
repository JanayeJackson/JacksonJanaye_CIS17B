/* 
 * File:   main.cpp
 * Author: Janaye Jackson
 *
 * Created on April 8th, 2024, 6:13 PM
 * Purpose: Create a shopping cart with a user and admin
 */

