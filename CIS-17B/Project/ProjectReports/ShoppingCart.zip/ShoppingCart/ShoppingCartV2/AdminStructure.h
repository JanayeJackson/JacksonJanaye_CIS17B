/* 
 * File:   AdminStructure.h
 * Author: Janaye Jackson
 *
 * Created on April 10th, 2024, 6:13 PM
 */

#ifndef ADMINSTRUCTURE_H
#define ADMINSTRUCTURE_H

#include <string>

struct admins {
    string user;
    string pass;
    string role;
};



#endif /* ADMINSTRUCTURE_H */

