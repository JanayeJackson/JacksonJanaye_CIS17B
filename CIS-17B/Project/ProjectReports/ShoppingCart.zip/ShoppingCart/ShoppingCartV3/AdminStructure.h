/* 
 * File:   AdminStructure.h
 * Author: Janaye Jackson
 *
 * Created on April 11th, 2024, 11:30 AM
 */

#ifndef ADMINSTRUCTURE_H
#define ADMINSTRUCTURE_H

#include <string>

struct admins {
    string user;
    string pass;
    string role;
};



#endif /* ADMINSTRUCTURE_H */

