/* 
 * File:   main.cpp
 * Author: Janaye Jackson
 *
 * Created on April 8th, 2024, 6:13 PM
 * Purpose: Create a shopping cart with a user and admin
 */

//System Level Libraries

#include <iostream>  //Input-Output Library
using namespace std;

//User Defined Libraries

//Global Constants, not Global Variables
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between
//systems of units

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map the inputs/known to the outputs
    
    //Display the outputs
    
    //Exit the program

    return 0;
}

