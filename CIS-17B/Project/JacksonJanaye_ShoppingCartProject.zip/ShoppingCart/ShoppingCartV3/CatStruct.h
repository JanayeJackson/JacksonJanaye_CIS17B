/* 
 * File:   CatStruct.h
 * Author: Janaye Jackson
 *
 * Created on April 11th, 2024, 11:30 AM
 */

#ifndef CATSTRUCT_H
#define CATSTRUCT_H

#include "itemStructure.h"

struct catalog{
    int nItems;
    item *cat;
};


#endif /* CATSTRUCT_H */

