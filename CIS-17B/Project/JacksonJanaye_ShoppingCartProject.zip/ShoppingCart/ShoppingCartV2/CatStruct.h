/* 
 * File:   CatStruct.h
 * Author: Janaye Jackson
 *
 * Created on April 10th, 2024, 6:48 PM
 */

#ifndef CATSTRUCT_H
#define CATSTRUCT_H

#include "itemStructure.h"

struct catalog{
    int nItems;
    item *cat;
};


#endif /* CATSTRUCT_H */

