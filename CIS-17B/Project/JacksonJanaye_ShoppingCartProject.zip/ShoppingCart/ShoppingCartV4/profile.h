/* 
 * File:   profile.h
 * Author: Janaye Jackson
 *
 * Created on April 12th, 2024, 12:01 PM
 */

#ifndef PROFILE_H
#define PROFILE_H

#include<string>

struct profile{
    string user;
    string pass;
};



#endif /* PROFILE_H */

