/* 
 * File:   AdminStructure.h
 * Author: Janaye Jackson
 *
 * Created on April 24th, 2024, 6:58 PM
 */

#ifndef ADMINSTRUCTURE_H
#define ADMINSTRUCTURE_H

#include <string>
#include "profile.h"

struct admins {
    profile *admin;
};



#endif /* ADMINSTRUCTURE_H */

