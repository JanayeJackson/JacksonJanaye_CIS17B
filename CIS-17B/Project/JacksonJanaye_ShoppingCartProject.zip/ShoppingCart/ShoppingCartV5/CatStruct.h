/* 
 * File:   CatStruct.h
 * Author: Janaye Jackson
 *
 * Created on April 24th, 2024, 6:58 PM
 */

#ifndef CATSTRUCT_H
#define CATSTRUCT_H

#include "itemStructure.h"

struct catalog{
    int nItems;
    item *cat;
};


#endif /* CATSTRUCT_H */

