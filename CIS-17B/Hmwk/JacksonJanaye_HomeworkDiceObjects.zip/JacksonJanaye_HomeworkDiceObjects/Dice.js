/* 
 * File:   Dice.js
 * Author: Janaye Jackson
 * Created on April 28th, 2024, 7:00 PM
 * Purpose:  To create and display faces of a dice
 */

//Constructor for the Card class
var MAXCRDS=6;
var MINCRDS=0;

function Dice(number){
    //Public properties of the class
    if(number>=MINCRDS&&number<MAXCRDS){
        this.number=number;
        this.setFace();
        this.setName();
        this.setPict();
    }else{
        this.number=-1;
        this.faceVal=-1;
        this.name="none";
        this.picture="none";
    }
}
//Setting the Face Value
Dice.prototype.setFace=function(){
    var num=this.number%6+1;
    this.faceVal=num;
};

//Determine the Face Name
Dice.prototype.setName=function(){
    switch(this.number%6){
        case 0:  this.name="One";  break;
        case 1:  this.name="Two";  break;
        case 2:  this.name="Three";break;
        case 3:  this.name="Four"; break;
        case 4:  this.name="Five"; break;
        case 5:  this.name="Six";  break;
        default: this.name="Bad Value";
    }
};

//Simply setting the picture
Dice.prototype.setPict=function(){
    this.picture="Faces/"+this.name+".png";
};

//To String function of the Card Class
Dice.prototype.toString=function(){
    document.write("<img src="+this.picture+" />");
    document.write("<br/>Number = "+this.number);
    document.write("<br/>Name = "+this.name);
    document.write("<br/>Face Value = "+this.faceVal);
    document.write("<br/><br/>");
};
