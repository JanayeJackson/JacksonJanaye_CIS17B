<?php
/* 
 * File:   Dice.php
 * Author: Janaye Jackson
 * Created on April 28th, 2024, 6:08 PM
 * Purpose:  To create and display faces of a dice
 */

define('MAXFACE',6);
define('MINFACE',0);

class Dice{
    
        private $number;
        private $faceVal;
        private $picture;
        private $name;
        
        private function setFace(){
            $num=$this->number%6+1;
            $this->faceVal=$num;
        }
        
        
        private function setName(){
            switch($this->number%6){
                case 0:  $this->name="One";  break;
                case 1:  $this->name="Two";  break;
                case 2:  $this->name="Three";break;
                case 3:  $this->name="Four"; break;
                case 4:  $this->name="Five"; break;
                case 5:  $this->name="Six";  break;
                default: $this->name="Bad Value";
            }
        }
        
        private function setPict(){
            $this->picture="Faces/".$this->name.".png";
        }

        public function __construct($number){
            if($number>=MINFACE&&$number<MAXFACE){
                $this->number=$number;
                $this->setFace();
                $this->setName();
                $this->setPict();
            }else{
                $this->number=-1;
                $this->faceVal=-1;
                $this->name="none";
                $this->picture="none";
            }
        }
        
        public function getNumr(){return $this->number;}
        public function getFace(){return $this->faceVal;}
        public function getName(){return $this->name;}
        public function getPict(){return $this->picture;}
        
        public function toString(){
            echo "<img src=".$this->picture." />";
            echo "<br/>Number = ".$this->number;
            echo "<br/>Name = ".$this->name;
            echo "<br/>Face Value = ".$this->faceVal;
            echo "<br/><br/>";
        }
}
?>