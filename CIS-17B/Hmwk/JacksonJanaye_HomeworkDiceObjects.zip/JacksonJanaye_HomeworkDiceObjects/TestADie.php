<!DOCTYPE html>
<!--
/* 
 * File:   TestADie.php
 * Author: Janaye Jackson
 * Created on April 28th, 2024, 6:08 PM
 * Purpose:  To create and display faces of a dice
 */
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Display Faces of Die</title>
        <?php   include './Dice.php';   ?>
    </head>
    <body>
        <?php
            //Test the Cards by creating a deck then printing the result
            $nFace = 6;
            $sides=array();
            for($i=0;$i<$nFace;$i++){
                $sides[$i]=new Dice($i);
                $sides[$i]->toString();
            }
        ?>
    </body>
</html>

