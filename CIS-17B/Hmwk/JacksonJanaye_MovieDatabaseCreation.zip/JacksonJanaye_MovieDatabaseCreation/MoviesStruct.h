/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MoviesStruct.h
 * Author: mlehr
 *
 * Created on July 14, 2021, 4:51 PM
 */

#include "MovieInfoSturc.h"

#ifndef MOVIESSTRUCT_H
#define MOVIESSTRUCT_H

struct Movies{
    int nMovies;
    MovieInfo *mveInfo;
};


#endif /* MOVIESSTRUCT_H */

